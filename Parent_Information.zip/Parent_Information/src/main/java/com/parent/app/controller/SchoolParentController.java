package com.parent.app.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.parent.app.model.ParentDetails;
import com.parent.app.service.ParentService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/a")
public class SchoolParentController {

		@Autowired
		private ParentService parentService;

		@GetMapping("/list")
		public List<ParentDetails> getAllParentDetails() {
			return parentService.listDetails();
		}

		@PostMapping("/add")
		public ParentDetails createParentDetails(@RequestBody ParentDetails parentDetials) {
			parentDetials.setRegisterDate(new Date(System.currentTimeMillis()));
			return parentService.addParentDetail(parentDetials);
		}

		@DeleteMapping("/delete/{id}")
		public ResponseEntity<String> deleteParentDetails(@PathVariable(value = "id") int Id) {
			return parentService.deleteParentDetail(Id);
			 
		}

	}


