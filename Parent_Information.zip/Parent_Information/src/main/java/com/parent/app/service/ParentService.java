package com.parent.app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.parent.app.model.ParentDetails;


public interface ParentService {

	List<ParentDetails> listDetails();

	ParentDetails addParentDetail(ParentDetails parentDetails);

	ResponseEntity<String> deleteParentDetail(int Id);



}
