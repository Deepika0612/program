package com.parent.app.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.parent.app.model.ParentDetails;
import com.parent.app.repository.ParentRepository;
import com.parent.app.service.ParentService;

	@Service
	public class ParentServiceImpl implements ParentService {

		@Autowired
		private ParentRepository parentRepo;

		@Override
		public List<ParentDetails> listDetails() {
			// TODO Auto-generated method stub
			return parentRepo.findAll();
		}

		@Override
		public ParentDetails addParentDetail(ParentDetails parentDetails) {
			// TODO Auto-generated method stub
			return parentRepo.save(parentDetails);
		}

		
		@Override
		public ResponseEntity<String> deleteParentDetail(int Id) {
			// TODO Auto-generated method stub
			ParentDetails parentUpdateDetails = parentRepo.findById(Id).orElse(new ParentDetails());
			if (parentUpdateDetails.getId() == Id) {
				System.out.println("Rejected");
				parentRepo.delete(parentUpdateDetails);
				return new ResponseEntity<String>("Parent Details Rejected", HttpStatus.OK);
			} else {
				return new ResponseEntity<String>("Error: Parent Details Not Found for this ID: " + Id,
						HttpStatus.BAD_REQUEST);
			}
		}
}
